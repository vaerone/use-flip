# use-flip

Lightweight React hooks for high-performance FLIP-based layout animations.

`use-flip` provides a minimal and dependency-free API for animating layout transitions in React applications using the **FLIP** animation technique (First → Last → Invert → Play).

Designed for:
- Reordering lists
- Expand/collapse transitions
- Dynamic grid layouts
- Shared layout animations
- UI state transitions after React renders

---

![npm](https://img.shields.io/npm/v/use-flip)
![bundle size](https://img.shields.io/bundlephobia/minzip/use-flip)
![license](https://img.shields.io/npm/l/use-flip)

---

# Features

- Zero runtime dependencies
- Tiny bundle size (~2 kB gzipped)
- GPU-accelerated animations
- React 17+ support
- TypeScript-first APIs
- Shared animation context
- List reordering support
- Reduced motion accessibility support
- ESM + CommonJS builds
- SSR-safe

---

# Installation

## npm

```bash
npm install use-flip
```

## pnpm

```bash
pnpm add use-flip
```

## yarn

```bash
yarn add use-flip
```

---

# Requirements

| Dependency | Version |
|---|---|
| React | >=17 |
| React DOM | >=17 |

---

# Why FLIP?

Traditional CSS transitions struggle with layout changes because browsers cannot properly interpolate between two independent layout states.

Animating properties like:
- `top`
- `left`
- `width`
- `height`

causes:
- layout recalculation
- repainting
- reflows
- janky transitions

FLIP solves this by animating only:
- `transform`
- `opacity`

which are GPU accelerated and significantly more performant.

---

# How FLIP Works

FLIP stands for:

1. **First** → capture the current layout
2. **Last** → render the updated layout
3. **Invert** → visually offset the element back to its old position
4. **Play** → animate the transform back to identity

This creates smooth transitions even when DOM layouts change drastically.

---

# API

---

# `useFlip`

Hook for animating a single element.

---

## Example

```tsx
import { useState } from "react";
import { useFlip } from "use-flip";

export function ExpandableCard() {
  const [expanded, setExpanded] = useState(false);

  const {
    ref,
    snapshot,
    isAnimating,
  } = useFlip<HTMLDivElement>({
    duration: 350,
    easing: "ease-out",
  });

  const toggle = () => {
    snapshot();

    setExpanded(prev => !prev);
  };

  return (
    <div
      ref={ref}
      onClick={toggle}
      style={{
        height: expanded ? 320 : 100,
        overflow: "hidden",
        cursor: "pointer",
      }}
    >
      {isAnimating ? "Animating..." : "Click to expand"}
    </div>
  );
}
```

---

## Configuration

| Option | Type | Default | Description |
|---|---|---|---|
| `duration` | `number` | `300` | Animation duration in milliseconds |
| `easing` | `string` | `"ease-out"` | CSS easing function |
| `delay` | `number` | `0` | Delay before animation |
| `animatePosition` | `boolean` | `true` | Animate translation |
| `animateSize` | `boolean` | `true` | Animate scaling |
| `animateOpacity` | `boolean` | `false` | Animate opacity |
| `onStart` | `(el) => void` | `undefined` | Triggered when animation starts |
| `onComplete` | `(el) => void` | `undefined` | Triggered when animation completes |

---

## Return Values

| Property | Type | Description |
|---|---|---|
| `ref` | `RefObject<HTMLElement>` | Attach to animated element |
| `snapshot()` | `() => void` | Capture current layout |
| `play()` | `() => void` | Manually trigger animation |
| `isAnimating` | `boolean` | Current animation state |

---

# `useFlipGroup`

Animate keyed collections such as:
- sortable lists
- filtered lists
- grids
- masonry layouts

---

## Example

```tsx
import { useState } from "react";
import { useFlipGroup } from "use-flip";

type Item = {
  id: number;
  name: string;
};

const initialItems: Item[] = [
  { id: 1, name: "React" },
  { id: 2, name: "TypeScript" },
  { id: 3, name: "FLIP" },
];

export function SortableList() {
  const [items, setItems] = useState(initialItems);

  const {
    getRef,
    snapshot,
  } = useFlipGroup({
    duration: 400,
  });

  const shuffle = () => {
    snapshot();

    setItems(prev =>
      [...prev].sort(() => Math.random() - 0.5)
    );
  };

  return (
    <div>
      <button onClick={shuffle}>
        Shuffle
      </button>

      <ul>
        {items.map(item => (
          <li
            key={item.id}
            ref={getRef(item.id)}
          >
            {item.name}
          </li>
        ))}
      </ul>
    </div>
  );
}
```

---

## Return Values

| Property | Type | Description |
|---|---|---|
| `getRef(key)` | `RefCallback<HTMLElement>` | Register list elements |
| `snapshot()` | `() => void` | Capture layouts before updates |
| `play()` | `() => void` | Trigger animations manually |

---

# `FlipProvider`

Coordinate animations across component trees and share animation configuration.

---

## Example

```tsx
import {
  FlipProvider,
  useFlipContext,
  useFlipRegistered,
} from "use-flip";

function Parent() {
  return (
    <FlipProvider
      duration={300}
      easing="ease-in-out"
    >
      <AnimatedItem id="a" />
      <AnimatedItem id="b" />
    </FlipProvider>
  );
}

function AnimatedItem({
  id,
}: {
  id: string;
}) {
  const ref = useFlipRegistered(id);

  return (
    <div ref={ref}>
      {id}
    </div>
  );
}
```

---

# Exported APIs

```ts
import {
  useFlip,
  useFlipGroup,
  FlipProvider,
  useFlipContext,
  useFlipRegistered,
} from "use-flip";
```

---

# Internal Architecture

```text
src/
├── FlipContext.tsx
├── index.ts
├── types.ts
├── useFlip.ts
├── useFlipGroup.ts
└── utils/
    ├── animation.ts
    └── rect.ts
```

---

## Architecture Overview

| Module | Responsibility |
|---|---|
| `useFlip.ts` | Single-element FLIP animations |
| `useFlipGroup.ts` | Group/list coordination |
| `FlipContext.tsx` | Shared animation context |
| `utils/animation.ts` | Animation orchestration |
| `utils/rect.ts` | DOMRect calculations and diffing |
| `types.ts` | Shared TypeScript types |

---

# Performance

Animations rely primarily on:
- `transform`
- `opacity`

Avoiding layout-heavy properties prevents:
- forced reflows
- layout thrashing
- excessive paint operations

This keeps transitions smooth even during rapid state changes.

---

# Accessibility

`use-flip` automatically respects:

```css
prefers-reduced-motion
```

When enabled, animations are skipped and elements transition instantly to their final state.

---

# SSR Compatibility

Safe for:
- Next.js
- Remix
- Astro
- other SSR frameworks

Animations execute only in browser environments.

---

# Best Use Cases

- Reordering lists
- Expand/collapse components
- Dynamic dashboards
- Shared layout transitions
- Animated filtering
- Grid transitions
- Accordion UIs

---

# Not Ideal For

- Physics simulations
- Gesture-heavy animations
- Complex timeline choreography
- 3D rendering systems
- Canvas/WebGL animation pipelines

---

# Browser Support

Uses:
- Web Animations API (WAAPI)
- `requestAnimationFrame` fallback

Supported in all modern browsers.

---

# Development

---

## Install dependencies

```bash
pnpm install
```

---

## Development mode

```bash
pnpm dev
```

---

## Build

```bash
pnpm build
```

---

## Type checking

```bash
pnpm typecheck
```

---

## Tests

```bash
pnpm test
```

---

## Coverage

```bash
pnpm test:coverage
```

---

## Bundle size

```bash
pnpm size
```

---

# Build Output

```text
dist/
├── index.js
├── index.mjs
└── index.d.ts
```

---

# Comparison

| Feature | use-flip | Framer Motion | react-spring |
|---|---|---|---|
| Bundle Size | ~2 kB | ~45 kB | ~26 kB |
| Layout Animation Model | Native FLIP | Layout Projection | Manual |
| Runtime Dependencies | 0 | Multiple | Multiple |
| TypeScript Support | Yes | Yes | Yes |
| Reduced Motion Support | Yes | Yes | Partial |
| Group Animations | Yes | Yes | Manual |

---

# License

MIT
